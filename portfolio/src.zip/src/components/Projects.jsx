import React from "react";

const Projects = () => {
  return (
    <section id="projects" style={{ textAlign: "center" }}>
      <h2>Projects</h2>
      <ul style={{ listStyle: "none", padding: 0 }}>
        <li><strong>Project 1</strong> - Short description</li>
        <li><strong>Project 2</strong> - Short description</li>
        <li><strong>Project 3</strong> - Short description</li>
      </ul>
    </section>
  );
};

export default Projects;
