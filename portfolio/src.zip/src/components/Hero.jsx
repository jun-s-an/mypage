import React from "react";

const Hero = () => {
  return (
    <section id="hero">
      <h1>Hi, I'm [Your Name] 👋</h1>
      <p>A passionate [Your Role] specializing in [Your Skills]</p>
    </section>
  );
};

export default Hero;
